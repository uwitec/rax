create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = erp, pg_catalog;

DROP INDEX erp.sell_status;
DROP INDEX erp."sell_item_sellId";
DROP INDEX erp.sell_date;
ALTER TABLE ONLY erp.ware DROP CONSTRAINT ware_p_key;
ALTER TABLE ONLY erp.ware_grouping DROP CONSTRAINT ware_grouping_p_key;
ALTER TABLE ONLY erp.ware_category DROP CONSTRAINT ware_category_p_key;
ALTER TABLE ONLY erp.sell DROP CONSTRAINT sell_p_key;
ALTER TABLE ONLY erp.sell_item DROP CONSTRAINT sell_lst_p_code;
ALTER TABLE ONLY erp."order" DROP CONSTRAINT order_p_key;
ALTER TABLE ONLY erp.order_item DROP CONSTRAINT order_lst_p_key;
ALTER TABLE erp.ware_grouping ALTER COLUMN id DROP DEFAULT;
ALTER TABLE erp.ware_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE erp.ware ALTER COLUMN id DROP DEFAULT;
ALTER TABLE erp.sell_item ALTER COLUMN id DROP DEFAULT;
ALTER TABLE erp.sell ALTER COLUMN id DROP DEFAULT;
ALTER TABLE erp.order_item ALTER COLUMN id DROP DEFAULT;
ALTER TABLE erp."order" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE erp.ware_id_seq;
DROP SEQUENCE erp.ware_grouping_id_seq;
DROP SEQUENCE erp.ware_category_id_seq;
DROP SEQUENCE erp.sell_item_id_seq;
DROP SEQUENCE erp.sell_id_seq;
DROP SEQUENCE erp.order_item_id_seq;
DROP SEQUENCE erp.order_id_seq;
DROP TABLE erp.ware_grouping;
DROP TABLE erp.ware_category;
DROP TABLE erp.ware;
DROP TABLE erp.sell_item;
DROP TABLE erp.sell;
DROP TABLE erp.order_item;
DROP TABLE erp."order";
DROP SCHEMA erp;
--
-- Name: erp; Type: SCHEMA; Schema: -; Owner: erp
--

CREATE SCHEMA erp;


ALTER SCHEMA erp OWNER TO erp;

SET search_path = erp, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: order; Type: TABLE; Schema: erp; Owner: erp; Tablespace: 
--

CREATE TABLE "order" (
    id integer NOT NULL,
    create_date timestamp without time zone NOT NULL,
    status integer NOT NULL,
    fee real NOT NULL
);


ALTER TABLE erp."order" OWNER TO erp;

--
-- Name: order_item; Type: TABLE; Schema: erp; Owner: erp; Tablespace: 
--

CREATE TABLE order_item (
    id integer NOT NULL,
    order_id integer NOT NULL,
    ware_id integer NOT NULL,
    cost real NOT NULL,
    number integer NOT NULL
);


ALTER TABLE erp.order_item OWNER TO erp;

--
-- Name: sell; Type: TABLE; Schema: erp; Owner: erp; Tablespace: 
--

CREATE TABLE sell (
    id integer NOT NULL,
    customer_name character varying(64) NOT NULL,
    customer_address character varying(128) NOT NULL,
    customer_phone1 character varying(64) NOT NULL,
    customer_phone2 character varying(64) NOT NULL,
    customer_postcode character varying(6) NOT NULL,
    fee real NOT NULL,
    fee_real real NOT NULL,
    create_date timestamp without time zone NOT NULL,
    express_id integer NOT NULL,
    customer_wangwang character varying(64),
    comment character varying(64) NOT NULL,
    sender character varying(8) NOT NULL,
    status integer NOT NULL,
    comment_express character varying(64),
    comment_invoice character varying(64),
    send_date timestamp without time zone
);


ALTER TABLE erp.sell OWNER TO erp;

--
-- Name: sell_item; Type: TABLE; Schema: erp; Owner: erp; Tablespace: 
--

CREATE TABLE sell_item (
    id integer NOT NULL,
    sell_id integer NOT NULL,
    ware_id integer NOT NULL,
    number integer NOT NULL,
    price real DEFAULT 0 NOT NULL
);


ALTER TABLE erp.sell_item OWNER TO erp;

--
-- Name: ware; Type: TABLE; Schema: erp; Owner: erp; Tablespace: 
--

CREATE TABLE ware (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    cost real DEFAULT 0 NOT NULL,
    price real DEFAULT 0 NOT NULL,
    number integer NOT NULL,
    barcode character varying(16)
);


ALTER TABLE erp.ware OWNER TO erp;

--
-- Name: COLUMN ware.cost; Type: COMMENT; Schema: erp; Owner: erp
--

COMMENT ON COLUMN ware.cost IS '0';


--
-- Name: ware_category; Type: TABLE; Schema: erp; Owner: erp; Tablespace: 
--

CREATE TABLE ware_category (
    id integer NOT NULL,
    name character varying(64) NOT NULL
);


ALTER TABLE erp.ware_category OWNER TO erp;

--
-- Name: ware_grouping; Type: TABLE; Schema: erp; Owner: erp; Tablespace: 
--

CREATE TABLE ware_grouping (
    id integer NOT NULL,
    ware_id integer NOT NULL,
    ware_category_id integer NOT NULL
);


ALTER TABLE erp.ware_grouping OWNER TO erp;

--
-- Name: order_id_seq; Type: SEQUENCE; Schema: erp; Owner: erp
--

CREATE SEQUENCE order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE erp.order_id_seq OWNER TO erp;

--
-- Name: order_id_seq; Type: SEQUENCE OWNED BY; Schema: erp; Owner: erp
--

ALTER SEQUENCE order_id_seq OWNED BY "order".id;


--
-- Name: order_id_seq; Type: SEQUENCE SET; Schema: erp; Owner: erp
--

SELECT pg_catalog.setval('order_id_seq', 1, false);


--
-- Name: order_item_id_seq; Type: SEQUENCE; Schema: erp; Owner: erp
--

CREATE SEQUENCE order_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE erp.order_item_id_seq OWNER TO erp;

--
-- Name: order_item_id_seq; Type: SEQUENCE OWNED BY; Schema: erp; Owner: erp
--

ALTER SEQUENCE order_item_id_seq OWNED BY order_item.id;


--
-- Name: order_item_id_seq; Type: SEQUENCE SET; Schema: erp; Owner: erp
--

SELECT pg_catalog.setval('order_item_id_seq', 1, false);


--
-- Name: sell_id_seq; Type: SEQUENCE; Schema: erp; Owner: erp
--

CREATE SEQUENCE sell_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE erp.sell_id_seq OWNER TO erp;

--
-- Name: sell_id_seq; Type: SEQUENCE OWNED BY; Schema: erp; Owner: erp
--

ALTER SEQUENCE sell_id_seq OWNED BY sell.id;


--
-- Name: sell_id_seq; Type: SEQUENCE SET; Schema: erp; Owner: erp
--

SELECT pg_catalog.setval('sell_id_seq', 86, true);


--
-- Name: sell_item_id_seq; Type: SEQUENCE; Schema: erp; Owner: erp
--

CREATE SEQUENCE sell_item_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE erp.sell_item_id_seq OWNER TO erp;

--
-- Name: sell_item_id_seq; Type: SEQUENCE OWNED BY; Schema: erp; Owner: erp
--

ALTER SEQUENCE sell_item_id_seq OWNED BY sell_item.id;


--
-- Name: sell_item_id_seq; Type: SEQUENCE SET; Schema: erp; Owner: erp
--

SELECT pg_catalog.setval('sell_item_id_seq', 163, true);


--
-- Name: ware_category_id_seq; Type: SEQUENCE; Schema: erp; Owner: erp
--

CREATE SEQUENCE ware_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE erp.ware_category_id_seq OWNER TO erp;

--
-- Name: ware_category_id_seq; Type: SEQUENCE OWNED BY; Schema: erp; Owner: erp
--

ALTER SEQUENCE ware_category_id_seq OWNED BY ware_category.id;


--
-- Name: ware_category_id_seq; Type: SEQUENCE SET; Schema: erp; Owner: erp
--

SELECT pg_catalog.setval('ware_category_id_seq', 1, false);


--
-- Name: ware_grouping_id_seq; Type: SEQUENCE; Schema: erp; Owner: erp
--

CREATE SEQUENCE ware_grouping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE erp.ware_grouping_id_seq OWNER TO erp;

--
-- Name: ware_grouping_id_seq; Type: SEQUENCE OWNED BY; Schema: erp; Owner: erp
--

ALTER SEQUENCE ware_grouping_id_seq OWNED BY ware_grouping.id;


--
-- Name: ware_grouping_id_seq; Type: SEQUENCE SET; Schema: erp; Owner: erp
--

SELECT pg_catalog.setval('ware_grouping_id_seq', 1, false);


--
-- Name: ware_id_seq; Type: SEQUENCE; Schema: erp; Owner: erp
--

CREATE SEQUENCE ware_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE erp.ware_id_seq OWNER TO erp;

--
-- Name: ware_id_seq; Type: SEQUENCE OWNED BY; Schema: erp; Owner: erp
--

ALTER SEQUENCE ware_id_seq OWNED BY ware.id;


--
-- Name: ware_id_seq; Type: SEQUENCE SET; Schema: erp; Owner: erp
--

SELECT pg_catalog.setval('ware_id_seq', 59, true);


--
-- Name: id; Type: DEFAULT; Schema: erp; Owner: erp
--

ALTER TABLE "order" ALTER COLUMN id SET DEFAULT nextval('order_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: erp; Owner: erp
--

ALTER TABLE order_item ALTER COLUMN id SET DEFAULT nextval('order_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: erp; Owner: erp
--

ALTER TABLE sell ALTER COLUMN id SET DEFAULT nextval('sell_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: erp; Owner: erp
--

ALTER TABLE sell_item ALTER COLUMN id SET DEFAULT nextval('sell_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: erp; Owner: erp
--

ALTER TABLE ware ALTER COLUMN id SET DEFAULT nextval('ware_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: erp; Owner: erp
--

ALTER TABLE ware_category ALTER COLUMN id SET DEFAULT nextval('ware_category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: erp; Owner: erp
--

ALTER TABLE ware_grouping ALTER COLUMN id SET DEFAULT nextval('ware_grouping_id_seq'::regclass);


--
-- Data for Name: order; Type: TABLE DATA; Schema: erp; Owner: erp
--

COPY "order" (id, create_date, status, fee) FROM stdin;
\.
copy "order" (id, create_date, status, fee)  from '$$PATH$$/1791.dat' ;
--
-- Data for Name: order_item; Type: TABLE DATA; Schema: erp; Owner: erp
--

COPY order_item (id, order_id, ware_id, cost, number) FROM stdin;
\.
copy order_item (id, order_id, ware_id, cost, number)  from '$$PATH$$/1792.dat' ;
--
-- Data for Name: sell; Type: TABLE DATA; Schema: erp; Owner: erp
--

COPY sell (id, customer_name, customer_address, customer_phone1, customer_phone2, customer_postcode, fee, fee_real, create_date, express_id, customer_wangwang, comment, sender, status, comment_express, comment_invoice, send_date) FROM stdin;
\.
copy sell (id, customer_name, customer_address, customer_phone1, customer_phone2, customer_postcode, fee, fee_real, create_date, express_id, customer_wangwang, comment, sender, status, comment_express, comment_invoice, send_date)  from '$$PATH$$/1793.dat' ;
--
-- Data for Name: sell_item; Type: TABLE DATA; Schema: erp; Owner: erp
--

COPY sell_item (id, sell_id, ware_id, number, price) FROM stdin;
\.
copy sell_item (id, sell_id, ware_id, number, price)  from '$$PATH$$/1794.dat' ;
--
-- Data for Name: ware; Type: TABLE DATA; Schema: erp; Owner: erp
--

COPY ware (id, name, cost, price, number, barcode) FROM stdin;
\.
copy ware (id, name, cost, price, number, barcode)  from '$$PATH$$/1795.dat' ;
--
-- Data for Name: ware_category; Type: TABLE DATA; Schema: erp; Owner: erp
--

COPY ware_category (id, name) FROM stdin;
\.
copy ware_category (id, name)  from '$$PATH$$/1796.dat' ;
--
-- Data for Name: ware_grouping; Type: TABLE DATA; Schema: erp; Owner: erp
--

COPY ware_grouping (id, ware_id, ware_category_id) FROM stdin;
\.
copy ware_grouping (id, ware_id, ware_category_id)  from '$$PATH$$/1797.dat' ;
--
-- Name: order_lst_p_key; Type: CONSTRAINT; Schema: erp; Owner: erp; Tablespace: 
--

ALTER TABLE ONLY order_item
    ADD CONSTRAINT order_lst_p_key PRIMARY KEY (id);


--
-- Name: order_p_key; Type: CONSTRAINT; Schema: erp; Owner: erp; Tablespace: 
--

ALTER TABLE ONLY "order"
    ADD CONSTRAINT order_p_key PRIMARY KEY (id);


--
-- Name: sell_lst_p_code; Type: CONSTRAINT; Schema: erp; Owner: erp; Tablespace: 
--

ALTER TABLE ONLY sell_item
    ADD CONSTRAINT sell_lst_p_code PRIMARY KEY (id);


--
-- Name: sell_p_key; Type: CONSTRAINT; Schema: erp; Owner: erp; Tablespace: 
--

ALTER TABLE ONLY sell
    ADD CONSTRAINT sell_p_key PRIMARY KEY (id);


--
-- Name: ware_category_p_key; Type: CONSTRAINT; Schema: erp; Owner: erp; Tablespace: 
--

ALTER TABLE ONLY ware_category
    ADD CONSTRAINT ware_category_p_key PRIMARY KEY (id);


--
-- Name: ware_grouping_p_key; Type: CONSTRAINT; Schema: erp; Owner: erp; Tablespace: 
--

ALTER TABLE ONLY ware_grouping
    ADD CONSTRAINT ware_grouping_p_key PRIMARY KEY (id);


--
-- Name: ware_p_key; Type: CONSTRAINT; Schema: erp; Owner: erp; Tablespace: 
--

ALTER TABLE ONLY ware
    ADD CONSTRAINT ware_p_key PRIMARY KEY (id);


--
-- Name: sell_date; Type: INDEX; Schema: erp; Owner: erp; Tablespace: 
--

CREATE INDEX sell_date ON sell USING btree (create_date);


--
-- Name: sell_item_sellId; Type: INDEX; Schema: erp; Owner: erp; Tablespace: 
--

CREATE INDEX "sell_item_sellId" ON sell_item USING btree (sell_id);


--
-- Name: sell_status; Type: INDEX; Schema: erp; Owner: erp; Tablespace: 
--

CREATE INDEX sell_status ON sell USING btree (status);


--
-- Name: erp; Type: ACL; Schema: -; Owner: erp
--

REVOKE ALL ON SCHEMA erp FROM PUBLIC;
REVOKE ALL ON SCHEMA erp FROM erp;
GRANT ALL ON SCHEMA erp TO erp;
GRANT ALL ON SCHEMA erp TO PUBLIC;


--
-- PostgreSQL database dump complete
--

